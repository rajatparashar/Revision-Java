package iteration;

public class DoWhileLoopDemo {
// do while loop executes at least once
	public static void main(String[] args) {
		int count = 1; // initialization
		do {
			System.out.println("Hello");
			count++; // increament
		} while (count <= 5);// condition checking
	}
}