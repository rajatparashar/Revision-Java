package iteration;

public class WhileLoopDemo {

	public static void main(String[] args) {
		int count = 1; // initialization

		while (count <= 5) { // condition checking
			System.out.println("Hello");
			count++; // increament
		}
	}
}