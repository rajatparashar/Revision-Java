package selection;

public class TernaryOperatorDemo {
	// ternary operator-> (condition)?expr1:expr2
	public static void main(String[] args) {
		int i = 8;
		int j = 0;
		j = (i>6)?1:2;
		System.out.println(j);
	}
}