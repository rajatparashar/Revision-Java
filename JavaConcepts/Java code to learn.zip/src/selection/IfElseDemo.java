package selection;

public class IfElseDemo {
	public static void main(String[] args) {
		int n = 23;
		if (n == 0) {
			System.out.println("Zero");
		} else if (n % 2 == 0) {
			System.out.println("Even");
		} else
			System.out.println("Odd");
	}
}